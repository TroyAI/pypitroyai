# pypitroyai
Script to upload a model to the server given an authentication token.
